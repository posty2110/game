import os
import time
from colorama import Fore , Back , Style

character = input("""Choose Character 
\n
1.Smiley Face
2.Brian Kings
3.Aaron Sparrow
4.Celine

👉""")

if character == "1":
 os.system("python .smiley/load.py")
