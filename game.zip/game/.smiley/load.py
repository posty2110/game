
import os
import time
from colorama import Fore 

stage = input(Fore.YELLOW + """Choose Level
\n
1. Stage 1: The Start
2. Stage 2: 
3. Stage 3:
4. Stage 4:
5. Stage 5:
👉 """)

if stage == "1":
 os.system("python .smiley.py")
elif stage == "2":
 key = "SM2" 
 print(key)
 passw = input(Fore.RED + """Enter Code to Continue \n """)
 if passw == key:
  print(Fore.GREEN + "correct√")
 else:
  print("Wrong Code!")
  again = input(Fore.WHITE + "Wanna try again?\n Yes or No \n👉  ")
  if again == "yes" or "Yes" or "y" or "Y":
   pass2 = input(Fore.RED + "Enter code \n👉  ")
   if pass2 == key:
    print(Fore.GREEN + "correct√")
   else :
    exit("Wrong Code")
  else:
   exit("Good Bye")

time.sleep(3)
os.system("python .part2.py")
