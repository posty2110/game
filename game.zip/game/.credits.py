import os

os.system("clear")
os.system("cat .cred")
