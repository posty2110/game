import os
import time
from colorama import Fore , Back , Style

os.system('toilet -f smblock --filter border:metal "ypcomics game" & play-audio .yp.mp3')
time.sleep(1)
print(Fore.RED + " BY 2110")
print("\n")
print(Fore.RED + "            SELECT\n\n\n\n" )
menu = input (Fore.WHITE + """1. START GAME 
2. OPTIONS
3. CREDITS
4. EXIT
👉 """)
if menu == "1":
 os.system("python user.py")
elif menu == "2":
 os.system("python .options.py")
elif menu == "3":
 os.system("python .credits.py")
elif menu == "4":
 print("GoodBye Quitter!")
 exit()
