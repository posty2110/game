import os
import time
from colorama import Fore , Back , Style

os.system('clear')
os.system('toilet -f smblock "OPTIONS"')
os.system("cat .op")
op = input("👉 ")
if op == "1":
 os.system("rm .users.txt")
if op == "2":
 os.system("python .lvl.py")
if op == "3":
 os.system("clear")
 os.system("python game.py")
