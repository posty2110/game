import os
import time
from colorama import Fore, Back, Style

os.system("clear")
print(Fore.MAGENTA + "You walk in just to find everyone dead , brutally murdered , blood all over the floor ...") 
action = input(Fore.WHITE + "What do you do?\n" + "1.Call the Police\n" + "2.Panic and go nuts!\n" + "3.Run!\n" + "> " )
if action == "1":
 print("Police: Sorry We Can't Help you right now call back after an hour")
 act = input("1.Panic\n" + "2.Wait\n" + "> ")
 if act == "1":
  print("You:\n" + Fore.RED + "What the Hell Happened Here? ..\n")
  time.sleep(2)
  print("This Musn't be True\n")
  time.sleep(2)
  print("It Cant be True! ..No\n")
  time.sleep(2)
  print("No!...No!...No..No..No..!\n")
  time.sleep(2)
  print("Nooooooooo!!!!!!!")
  time.sleep(3)
 elif act == "2":
  os.system("clear")
  print(" Been an Hour and you call back ...the police don't respond to your 5 calls ..")
  act = input("1.Panic\n" + "2.Give up\n" + "> ")
  if act == "1":
   print("......")
   time.sleep(3)
   print("You:)")
   time.sleep(2)
   print(Fore.RED + "I'll kill who did this!")
   time.sleep(4)
  elif act == "2":
   print("How you wanna give up?")
   input("1.hang yourself\n" + "2.jump off a cliff\n" + "> ")
   time.sleep(3)
   print("you dont die! so you panic! ..wondering how and why")
   time.sleep(4)
elif action == "2":
 print("You:" + Fore.RED )
 print("I'm Gonna Kill who so Ever did this !!!!!!!!")
 time.sleep(2)
 print("=_=")
 time.sleep(4) 
elif action == "3":
 print("You run , run and run " + "\n then you panic")
 time.sleep(3)
 print("You:\n" + Fore.RED + "Who ever did this shall die")
 time.sleep(4)

os.system("cat file")
os.system("clear")

print(Fore.GREEN + " Later cops arrive at the scene and follow you up ...Ask you a Couple of Questions ...You answer them ..The let you leave as they carry on the investigation ...You letter Head back to seek for help from the Church")

time.sleep(5)

os.system("clear")

os.system("cat church")

check = input(Fore.BLUE + "Enjoying the game?\n" + ">> ")
if check == "yes" or "y" or "Y":
 print("Kindly Follow me")
 time.sleep(4)
 os.system("xdg-open http://facebook.com/myron2110")
 time.sleep(5)
 os.system("xdg-open http://github.com/posty2110")

