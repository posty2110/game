import os
from colorama import Fore, Back, Style
import time
os.system("clear")
print('      WELCOME TO THE CHURCH\n\n')
time.sleep(2)
print("Father Chris:\n\n")
time.sleep(2)
print('"We are the Sun God Worshippers .Who ever dedicates his life to the sun will be blessed for the sun is God. the Day was meant for God to watch over us .the night? , Thats up to you to figure Out"')
time.sleep(7)

input(Fore.GREEN + "\npress enter to continue\n")

os.system(Fore.WHITE )
os.system("clear")
os.system("cat church.sh")
print("yes or no?")
trial = input("> ")

if trial == "yes":
 questions = "1. What did you mean bout the night being ours to figure out?\n" + "2. Can this so God help me and my family?\n" +  "3. Tell me Father , have you seen this God?\n"
 ask = input("\nchoose a question to ask\n\n" + questions + "> ")
 if ask == "1":
  print("find out tonight")
 elif ask == "2":
  print("Yes if you believe and obey")
 elif ask == "3":
  name = input("\n\nYou must be new , Tell me whats your name? \n" + "> ")
  print("Nice to have you here " + name + " ,to answer that question ")
  time.sleep(2)
  print("\nYes i have")
  
else :
 print("alright sir")

time.sleep(3)

os.system("clear")


print(Fore.GREEN + "Later that day ...Mike went to a circus to play as a clown to make money for his wife and daughter Celine , after the circus was done ..You , Mike Ryans decided to go home ...as you reach out to your front door ..What do you do?")
action = input(Fore.WHITE + "1. Knock at the door?\n" + "2. Leave and walk away ?\n" + "3. Enter the house?\n" + "> ")
if action == "1":
 print("...........")
 print(Fore.RED + "You get no response")
 action2 = input(Fore.WHITE + "1. Knock again\n" + "2. Leave and walk away ?\n" + "3. Enter the house?\n" + "> ")
 if action2 == "1":
  print("........")
  print(Fore.RED + "You get no response")
  action3 = input(Fore.WHITE + "1.Leave\n" + "2.Enter the House\n" + "> ")
  if action3 == "1":
   game = input("game over\n" + "1. quit\n" + "2. try again?\n" + "> ")
   if game == "1":
    exit(Fore.BLUE + " Thanks for playing with 2110")
   elif game ==  "2":
    print("\nYou Entered the House")
  elif action3 == "2":
   print("you entered the house ")
 elif action2 == "2":
  game = input("game over\n" + "1. quit\n" + "2. try again?\n" + "> ")
  if game == "1":
   exit(Fore.BLUE + " Thanks for playing with 2110")
  elif game ==  "2":
   print("\nYou Entered the House")
 elif action2 == "3":
  print("\nYou Entered the House")
elif action == "2":
 game = input("game over\n" + "1. quit\n" + "2. try again?\n" + "> ")
 if game == "1":
  exit(Fore.BLUE + " Thanks for playing with 2110")
 elif game ==  "2":
  print("\nYou Entered the House")
elif action == "3":
 print("\nYou Entered the House")

print(Fore.RED + "\n Your Save Code is SM2")
print(" Use SM2 next time when playing to skip first part")
time.sleep(5)
os.system("python .part2.py")
