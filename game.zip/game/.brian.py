import os
import time

os.system("clear")

print("Pete:'Brian!,i need your help!'")
