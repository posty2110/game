# Welcome to the Quest Game ....
# This is based on YPComics characters
# If you have fun playing the game 
# Follow my github @Posty2110
# Written in Simple Python 
# You can change names , rules , any
# credits all to Posty2110
# Code below :
#########################################
#os.system("clear")
#time.sleep(0.5)
#print('loading')
#print('#')
#time.sleep(1)
#print('##')
#time.sleep(1)
#print('###')
#time.sleep(1)
#print('######')
#time.sleep(1)
#print('##########')
#time.sleep(2)
#print(' completed ')

import os
import time
try:
    import colorama
except(ImportError):
    os.system("pip install colorama")

os.system("cat .banner")

time.sleep(1.5)
os.system("clear")

time.sleep(0.2)
one = "Smiley"
two = "Brian"
three = "Aaron"
four = "Celine"
characters = "1. Smiley Face\n" + "2. Brian kings\n" + "3. Aaron sparrow\n" + "4. Celine\n"
character = input("SELECT CHARACTER\n" + characters + "> ")
if character == "1" :
 character = one
 os.system("clear")
 os.system("cat .smile") 
 time.sleep(3)
 os.system("python .smiley.py")
elif character == "2" :
 character = two
 os.system("clear")
 print("Hello " + character + " you're a hero who needs to save the world from your beloved cousin Seth.Who's tried countless times to kill you!" + "\nguess this is time to put an end to his madness?" )
 answer = input("What do you say?\n" + "Yes or No" + "> ")
 if answer == "y" or "yes" or "ues" or "Yes":
  print("Lets go kill this son of a gun!")
  time.sleep(1)
  os.system("python .brian.py")
 elif answer != "no":
  print("nah")

