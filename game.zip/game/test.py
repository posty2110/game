# list of names
names = input([])

# open file in write mode
with open(r'user.txt', 'w') as fp:
    for item in names:
        # write each item on a new line
        fp.write("%s\n" % item)
    print('Done')
