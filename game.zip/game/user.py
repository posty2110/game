import os
import time
from colorama import Fore , Back , Style


users = open("user.txt" , "w")
users.write("" + input())
users.close
